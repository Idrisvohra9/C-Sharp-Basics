﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;



namespace databasedemo
{
    public class DbConnect
    {
        private readonly string _connectionString = ConfigurationManager.ConnectionStrings["SampleDbConnect"].ConnectionString;

        public void ExecuteNonQuery(string query)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
        }

        public DataTable ExecuteAdapter(string query)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(dt);
                return dt;
            }
        }
    }
}
