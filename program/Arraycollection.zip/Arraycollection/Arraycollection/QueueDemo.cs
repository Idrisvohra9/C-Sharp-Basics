﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
namespace Arraycollection
{
    class QueueDemo
    {
        static void Main(string[] args)
        {





            //Queue q1 = new Queue();
            //q1.Enqueue(1);
            //q1.Enqueue(2);
            //q1.Enqueue(3);
            //q1.Enqueue(4);
            //q1.Enqueue(5);
            //q1.Enqueue(6);
            //q1.Enqueue(7);
            //q1.Enqueue(8);
            //foreach (var item in q1)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("after Dequeue");
            //q1.Dequeue();
            //q1.Dequeue();
            //Console.WriteLine("----------------");
            //foreach (var item in q1)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("total element="+q1.Count);
            ////while (q1.Count > 0)
            ////{
            ////    Console.WriteLine(q1.Dequeue()) ;
            ////}
            ////Console.WriteLine("-----------");
            ////foreach (var item in q1)
            ////{
            ////    Console.WriteLine(item);
            ////}
            //Console.WriteLine(q1.Peek());
            //Console.WriteLine(q1.Contains(16));

            //Queue<int> q1 = new Queue<int>();
            //q1.Enqueue(12);
            //q1.Enqueue(2);
            //q1.Enqueue(32);

            //q1.Enqueue(22);
            //q1.Enqueue(10);
            
            //q1.Dequeue();
            //q1.Dequeue();
            //Console.WriteLine("After dequeue");
            //foreach (var item in q1)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine(q1.Peek());
            Console.ReadKey();
        }
    }
}