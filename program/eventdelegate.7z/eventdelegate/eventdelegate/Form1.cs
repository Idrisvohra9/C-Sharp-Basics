﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace eventdelegate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Button b = new Button();
            //b.Text = "press";
            //b.Size = new Size(100, 50);
            //b.Location=new Point(100,100);
            //this.Controls.Add(b);
            //b.Click += new EventHandler(b_click);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
        //private void b_click(object sender, EventArgs e)
        //{
        //    MessageBox.Show("hello");
        //}

       
    }
}
