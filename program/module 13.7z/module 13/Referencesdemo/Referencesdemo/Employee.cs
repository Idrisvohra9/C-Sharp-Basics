﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Referencesdemo
{
   public class Employee
    {
       public int id;
       public string name;
       
       public Employee(int i,string nm)
       {

           id = i;
           name = nm;
       }
    }
}
