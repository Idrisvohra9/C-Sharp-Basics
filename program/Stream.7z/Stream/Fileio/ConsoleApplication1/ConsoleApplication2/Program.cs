﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplication1;
namespace ConsoleApplication2
{
    
    class Program :A
    {
        static void Main(string[] args)
        {
            Employee e1 = new Employee(102, "dhara");
            Program p = new Program();
           
            a1.id = 2;
            e1.show();
            
            Console.ReadKey();
        }
    }
}
