﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Access_specifiers1;
namespace Access_specifires2
{
    class Program2
    {
        static void Main(string[] args)
        {
            class1 c1 = new class1();
            c1.show();
            Console.ReadKey();
        }
    }
}
