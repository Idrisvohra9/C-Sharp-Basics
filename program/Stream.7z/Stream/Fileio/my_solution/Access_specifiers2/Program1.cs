﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Access_specifiers1
{
    public class class1
    {
        public void show()
        {
            Console.WriteLine("this is public methodx");
        }
    }
    class Program1
    {
        static void Main(string[] args)
        {
        }
    }
}
